package com.team80;

public enum User {
    HOST, TRAVELER, ADMIN
}