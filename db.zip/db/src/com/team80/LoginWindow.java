package com.team80;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JPasswordField;

public class LoginWindow extends JFrame {

	private JPanel contentPane;
	private JTextField idTextField;
	private User user;
	private JFrame userEditor;
	private JButton loginBtn;
	private JPasswordField passwordField;
	private JTextField msgField;

	/**
	 * Create the frame.
	 */
	public LoginWindow(User user) {
		JFrame that = this;
		this.user = user;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("Username");
		idLabel.setBounds(51, 55, 107, 26);
		contentPane.add(idLabel);
		
		JLabel pwLabel = new JLabel("Password");
		pwLabel.setBounds(51, 115, 107, 26);
		contentPane.add(pwLabel);
		
		idTextField = new JTextField();
		idTextField.setBounds(165, 52, 186, 32);
		contentPane.add(idTextField);
		idTextField.setColumns(10);
		
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (login()) {
					userEditor = new HostEditor();
					userEditor.setVisible(true);
					that.setVisible(false);	
				}
			}
		});
		loginBtn.setBounds(51, 173, 92, 35);
		contentPane.add(loginBtn);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(165, 112, 186, 32);
		contentPane.add(passwordField);
		
		msgField = new JTextField();
		msgField.setEditable(false);
		msgField.setColumns(10);
		msgField.setBounds(165, 174, 186, 32);
		contentPane.add(msgField);
	}
	
	public boolean login() {
		final PersistenceLayer persistenceLayer;
		boolean loggedIn = false;
		try {
			persistenceLayer = PersistenceLayer.getInstance();
            final Connection con = persistenceLayer.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Hosts WHERE cid = ?");
            int cid = Integer.parseInt(idTextField.getText());
            ps.setInt(1, cid);
            final ResultSet rs = ps.executeQuery();
            if (rs.next()) {
            	msgField.setText("Login successful.");
            	loggedIn = true;
            } else {
            	msgField.setText("Login failed.");
            	loggedIn = false; 
            }
            persistenceLayer.closeConnection(); 
        } catch(final SQLException e) {
            System.err.println("An error occurred while executing query.");
            System.err.println(e.getMessage());
        } 
        
		return loggedIn;
	}
}
