package com.team80;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class App {

	private JFrame frame;
	private static PersistenceLayer persistenceLayer;
	private LoginWindow loginWin; 
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App window = new App();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton signUpBtn = new JButton("Sign up");
		signUpBtn.setBounds(68, 173, 141, 35);
		frame.getContentPane().add(signUpBtn);
		
		JButton signInBtn = new JButton("Sign in");
		
		signInBtn.setBounds(231, 173, 141, 35);
		frame.getContentPane().add(signInBtn);
		
		JRadioButton hRB = new JRadioButton("Host");
		hRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signUpBtn.setEnabled(true);
			}
		});
		hRB.setBounds(68, 17, 201, 35);
		frame.getContentPane().add(hRB);
		
		JRadioButton tRB = new JRadioButton("Traveler");
		tRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signUpBtn.setEnabled(true);
			}
		});
		tRB.setBounds(68, 65, 201, 35);
		frame.getContentPane().add(tRB);
		
		JRadioButton aRB = new JRadioButton("Admin");
		aRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(aRB.isSelected()){
		            signUpBtn.setEnabled(false);
		        }
			}
		});
		aRB.setBounds(68, 113, 201, 35);
		frame.getContentPane().add(aRB);
		
		//Group the radio buttons.
	    ButtonGroup group = new ButtonGroup();
	    group.add(hRB);
	    group.add(tRB);
	    group.add(aRB);
	    hRB.setSelected(true);
		
		persistenceLayer = PersistenceLayer.getInstance();
        SQLUtil.connectOracle();
        persistenceLayer.closeConnection(); // actually this should be called when we close the app,
        // but there is not such button yet
	    
	    signInBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (hRB.isSelected()) {
					loginWin = new LoginWindow(User.HOST);
				} else if (tRB.isSelected()) {
					loginWin = new LoginWindow(User.TRAVELER);
				} else {
					loginWin = new LoginWindow(User.ADMIN);
				}
				loginWin.setVisible(true);
			}
		});
	}
}
